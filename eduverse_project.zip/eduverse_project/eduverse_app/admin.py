from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Course, Lesson, Quiz, Question, ExamResult, Certificate, Enrollment, LessonProgress

# Register your models here.

class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'role', 'is_staff', 'is_active')
    list_filter = ('role', 'is_staff', 'is_active')
    search_fields = ('username', 'email')
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('role',)}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        (None, {'fields': ('role',)}),
    )

    actions = ['ban_users', 'unban_users']

    def ban_users(self, request, queryset):
        queryset.update(is_active=False)
        self.message_user(request, "Selected users have been banned successfully.")
    ban_users.short_description = "Ban selected users"

    def unban_users(self, request, queryset):
        queryset.update(is_active=True)
        self.message_user(request, "Selected users have been unbanned successfully.")
    unban_users.short_description = "Unban selected users"

class LessonInline(admin.TabularInline):
    model = Lesson
    extra = 1

class QuestionInline(admin.TabularInline):
    model = Question
    extra = 1

class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'teacher', 'created_at')
    list_filter = ('category', 'created_at', 'teacher')
    search_fields = ('title', 'description')
    inlines = [LessonInline]

class QuizAdmin(admin.ModelAdmin):
    list_display = ('title', 'course', 'passing_score')
    inlines = [QuestionInline]

class ExamResultAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'score', 'passed', 'taken_at')
    list_filter = ('passed', 'taken_at', 'course')

class CertificateAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'certificate_id', 'issue_date')
    readonly_fields = ('certificate_id', 'issue_date')

class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'enrolled_at', 'completed_at')
    list_filter = ('enrolled_at', 'completed_at')

class LessonProgressAdmin(admin.ModelAdmin):
    list_display = ('user', 'lesson', 'completed', 'completed_at')
    list_filter = ('completed', 'completed_at')

admin.site.register(User, CustomUserAdmin)
admin.site.register(Course, CourseAdmin)
admin.site.register(Lesson)
admin.site.register(Quiz, QuizAdmin)
admin.site.register(Question)
admin.site.register(ExamResult, ExamResultAdmin)
admin.site.register(Certificate, CertificateAdmin)
admin.site.register(Enrollment, EnrollmentAdmin)
admin.site.register(LessonProgress, LessonProgressAdmin)

from .models_settings import SiteSetting, FooterLink

class FooterLinkInline(admin.TabularInline):
    model = FooterLink
    extra = 1

@admin.register(SiteSetting)
class SiteSettingAdmin(admin.ModelAdmin):
    list_display = ('site_name', 'contact_email', 'version')
    def has_add_permission(self, request):
        if self.model.objects.exists():
            return False
        return super().has_add_permission(request)

@admin.register(FooterLink)
class FooterLinkAdmin(admin.ModelAdmin):
    list_display = ('title', 'url', 'order')
    list_editable = ('order', 'url')
