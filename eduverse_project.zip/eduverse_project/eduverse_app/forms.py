from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Course, Quiz, Lesson, Question, Review

class UserRegistrationForm(UserCreationForm):
    role = forms.ChoiceField(
        choices=[(r, l) for r, l in User.ROLE_CHOICES if r != 'admin'],
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    class Meta(UserCreationForm.Meta):
        model = User
        fields = UserCreationForm.Meta.fields + ('role',)

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = [
            'title',
            'category',
            'description',
            'duration_hours',
            'price',
            'image',
        ]

        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'category': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'duration_hours': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g. 12'
            }),
            'price': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g. 49.99',
                'step': '0.01'
            }),
            'image': forms.FileInput(attrs={
                'class': 'form-control'
            }),
        }
class QuizForm(forms.ModelForm):
    class Meta:
        model = Quiz
        fields = ['title', 'passing_score']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Quiz Title'}),
            'passing_score': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Passing Score (%)'}),
        }

class LessonForm(forms.ModelForm):
    class Meta:
        model = Lesson
        fields = ['title', 'video_url', 'video_file', 'order']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Lesson Title'}),
            'video_url': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'YouTube Video URL'}),
            'video_file': forms.FileInput(attrs={'class': 'form-control'}),
            'order': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Order (e.g. 1)'}),
        }

class QuestionForm(forms.ModelForm):
    option1 = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Option 1'}), label="Option 1")
    option2 = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Option 2'}), label="Option 2")
    option3 = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Option 3'}), label="Option 3")
    option4 = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Option 4'}), label="Option 4")

    class Meta:
        model = Question
        fields = ['question_text', 'correct_answer']
        widgets = {
            'question_text': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Question Text'}),
            'correct_answer': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Correct Answer (Must match one of the options)'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        opt1 = cleaned_data.get('option1')
        opt2 = cleaned_data.get('option2')
        opt3 = cleaned_data.get('option3')
        opt4 = cleaned_data.get('option4')
        correct_answer = cleaned_data.get('correct_answer')

        options = [opt for opt in [opt1, opt2, opt3, opt4] if opt and opt.strip()]
        
        if len(options) < 2:
            raise forms.ValidationError("Please provide at least 2 options.")
            
        cleaned_data['options'] = options
        
        if correct_answer and correct_answer not in options:
            self.add_error('correct_answer', "The correct answer must be one of the provided options.")
        
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.options = self.cleaned_data['options']
        if commit:
            instance.save()
        return instance

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'bio', 'profile_picture']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'bio': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'profile_picture': forms.FileInput(attrs={'class': 'form-control'}),
        }

class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ['rating', 'comment']
        widgets = {
            'rating': forms.Select(attrs={'class': 'form-select'}),
            'comment': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Write your review here...'}),
        }
