from django.apps import apps

def site_settings(request):
    """
    Context processor to make site settings and footer links available globally.
    Uses apps.get_model to safely retrieve models and avoid circular import issues.
    """
    try:
        SiteSetting = apps.get_model('eduverse_app', 'SiteSetting')
        settings = SiteSetting.objects.first()
        if not settings:
            settings = SiteSetting.objects.create()
    except Exception:
        settings = None
    
    try:
        FooterLink = apps.get_model('eduverse_app', 'FooterLink')
        footer_links = FooterLink.objects.all()
    except Exception:
        footer_links = []
    
    return {'site_settings': settings, 'footer_links': footer_links}
