from .models_settings import SiteSetting, FooterLink

def site_settings(request):
    try:
        settings = SiteSetting.objects.first()
        if not settings:
            settings = SiteSetting.objects.create()
    except:
        settings = None
    
    try:
        footer_links = FooterLink.objects.all()
    except:
        footer_links = []
    
    return {'site_settings': settings, 'footer_links': footer_links}
