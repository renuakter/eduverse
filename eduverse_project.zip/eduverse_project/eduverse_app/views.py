from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse
import stripe
from django.conf import settings
from rest_framework import generics, permissions, status, views
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.db.models import Count, Avg, Sum, Q
from .models import User, Course, Lesson, Quiz, Question, ExamResult, Certificate, Enrollment, LessonProgress, Review, LiveClass, LiveClassQuestion, LiveClassAnswer, Assignment, AssignmentSubmission, Payment, SiteSetting
from .serializers import (
    UserSerializer, LoginSerializer, CourseSerializer, LessonSerializer,
    QuizSerializer, QuestionSerializer, ExamResultSerializer, CertificateSerializer,
    EnrollmentSerializer, LessonProgressSerializer
)
from .utils import save_certificate_pdf
from django.utils import timezone

from eduverse_app import serializers

# Custom permissions
class IsAdminOrReadOnly(permissions.BasePermission):
    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True
        return request.user and request.user.is_authenticated and request.user.role == 'admin'

class IsAdminUserRole(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.role == 'admin'

# Authentication Views
class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.AllowAny]

class LoginView(views.APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        
        from rest_framework_simplejwt.tokens import RefreshToken
        refresh = RefreshToken.for_user(user)

        return Response({
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'user': UserSerializer(user).data
        })

# Course Views
class CourseListView(generics.ListCreateAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def perform_create(self, serializer):
        if not self.request.user.role == 'admin':
             raise permissions.PermissionDenied("Only admins can create courses.")
        serializer.save(teacher=self.request.user)

class CourseDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    
    def perform_update(self, serializer):
        if not self.request.user.role == 'admin':
             raise permissions.PermissionDenied("Only admins can update courses.")
        serializer.save()

    def perform_destroy(self, instance):
        if not self.request.user.role == 'admin':
             raise permissions.PermissionDenied("Only admins can delete courses.")
        instance.delete()

class LessonListView(generics.ListCreateAPIView):
    serializer_class = LessonSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        course_id = self.kwargs.get('course_id')
        return Lesson.objects.filter(course_id=course_id)

    def perform_create(self, serializer):
        if not self.request.user.role == 'admin':
             raise permissions.PermissionDenied("Only admins can create lessons.")
        course = get_object_or_404(Course, pk=self.kwargs.get('course_id'))
        serializer.save(course=course)

# Quiz & Exam Views
class QuizDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = QuizSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_object(self):
        course_id = self.kwargs.get('course_id')
        return get_object_or_404(Quiz, course_id=course_id)
    
    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['include_questions'] = True
        return context

    def perform_update(self, serializer):
        if not self.request.user.role == 'admin':
             raise permissions.PermissionDenied("Only admins can update quizzes.")
        serializer.save()

class TakeExamView(views.APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, course_id):
        course = get_object_or_404(Course, id=course_id)
        
        # Check enrollment
        if not Enrollment.objects.filter(user=request.user, course=course).exists():
            return Response({"error": "You are not enrolled in this course."}, status=status.HTTP_403_FORBIDDEN)

        try:
            quiz = course.quiz
        except Quiz.DoesNotExist:
            return Response({"error": "No quiz available for this course."}, status=status.HTTP_404_NOT_FOUND)

        answers = request.data.get('answers', {}) # Dict of question_id: selected_option
        if not answers:
             return Response({"error": "No answers provided."}, status=status.HTTP_400_BAD_REQUEST)

        questions = quiz.questions.all()
        total_questions = questions.count()
        if total_questions == 0:
             return Response({"error": "Quiz has no questions."}, status=status.HTTP_400_BAD_REQUEST)
        
        correct_count = 0
        
        for question in questions:
            user_answer = answers.get(str(question.id))
            if user_answer and user_answer == question.correct_answer:
                correct_count += 1
        
        score_percentage = (correct_count / total_questions) * 100
        passed = score_percentage >= quiz.passing_score
        
        # Save result
        result = ExamResult.objects.create(
            user=request.user,
            course=course,
            score=score_percentage,
            passed=passed
        )
        
        certificate_data = None
        if passed:
            # Check if certificate already exists
            cert, created = Certificate.objects.get_or_create(
                user=request.user,
                course=course,
                defaults={'issue_date': timezone.now()}
            )
            # Generate PDF if it doesn't exist or just return it?
            # Let's generate it anyway to be safe or update it
            save_certificate_pdf(cert)
            certificate_data = CertificateSerializer(cert).data
            
            # Update enrollment completed status
            enrollment = Enrollment.objects.get(user=request.user, course=course)
            if not enrollment.completed_at:
                enrollment.completed_at = timezone.now()
                enrollment.save()

        return Response({
            'score': score_percentage,
            'passed': passed,
            'correct_count': correct_count,
            'total_questions': total_questions,
            'certificate': certificate_data
        })

# Certificate Views
class UserCertificatesView(generics.ListAPIView):
    serializer_class = CertificateSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Certificate.objects.filter(user=self.request.user)

# Enrollment Views
class EnrollmentListView(generics.ListCreateAPIView):
    serializer_class = EnrollmentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Enrollment.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        course_id = self.request.data.get('course_id')
        course = get_object_or_404(Course, id=course_id)
        if Enrollment.objects.filter(user=self.request.user, course=course).exists():
             raise serializers.ValidationError("Already enrolled")
        serializer.save(user=self.request.user, course=course)

    def create(self, request, *args, **kwargs):
        # Custom create to handle the course_id being passed differently or just validation
        course_id = request.data.get('course_id')
        if not course_id:
            return Response({"error": "course_id is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        course = get_object_or_404(Course, id=course_id)
        if Enrollment.objects.filter(user=request.user, course=course).exists():
             return Response({"error": "Already enrolled"}, status=status.HTTP_400_BAD_REQUEST)
             
        enrollment = Enrollment.objects.create(user=request.user, course=course)
        serializer = self.get_serializer(enrollment)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class EnrollmentDetailView(generics.RetrieveDestroyAPIView):
    serializer_class = EnrollmentSerializer
    permission_classes = [IsAuthenticated]
    queryset = Enrollment.objects.all()

    def get_queryset(self):
        return Enrollment.objects.filter(user=self.request.user)

# Progress Views
class LessonProgressListView(generics.ListAPIView):
    serializer_class = LessonProgressSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return LessonProgress.objects.filter(user=self.request.user)

class LessonProgressDetailView(generics.RetrieveUpdateAPIView):
    serializer_class = LessonProgressSerializer
    permission_classes = [IsAuthenticated]
    queryset = LessonProgress.objects.all()
    
    def get_queryset(self):
        return LessonProgress.objects.filter(user=self.request.user)
    
    def perform_update(self, serializer):
        instance = serializer.save()
        if instance.completed and not instance.completed_at:
            instance.completed_at = timezone.now()
            instance.save()

# Admin Views
class AdminDashboardView(views.APIView):
    permission_classes = [IsAdminUserRole]

    def get(self, request):
        total_users = User.objects.filter(role='user').count()
        total_courses = Course.objects.count()
        total_enrollments = Enrollment.objects.count()
        total_certificates = Certificate.objects.count()
        
        recent_enrollments = Enrollment.objects.order_by('-enrolled_at')[:5]
        recent_enrollments_data = EnrollmentSerializer(recent_enrollments, many=True).data
        
        return Response({
            'total_users': total_users,
            'total_courses': total_courses,
            'total_enrollments': total_enrollments,
            'total_certificates': total_certificates,
            'recent_enrollments': recent_enrollments_data
        })

class AdminUserManagementView(generics.ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAdminUserRole]

class AdminExamResultsView(generics.ListAPIView):
    queryset = ExamResult.objects.all()
    serializer_class = ExamResultSerializer
    permission_classes = [IsAdminUserRole]

class AdminCertificatesView(generics.ListAPIView):
    queryset = Certificate.objects.all()
    serializer_class = CertificateSerializer
    permission_classes = [IsAdminUserRole]


# Template Views (Frontend)
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from .forms import UserRegistrationForm, CourseForm, QuizForm, LessonForm, QuestionForm, UserProfileForm, ReviewForm, LiveClassForm, LiveClassQuestionForm, LiveClassAnswerForm, AssignmentForm, AssignmentSubmissionForm
from django.contrib import messages

def register_view(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f"Welcome to EduVerse, {user.username}!")
            return redirect('course_list')
    else:
        form = UserRegistrationForm()
    return render(request, 'eduverse_app/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                return redirect('course_list')
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, 'eduverse_app/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('login')

@login_required
def profile_view(request, username=None):
    if username:
        view_user = get_object_or_404(User, username=username)
    else:
        view_user = request.user
        
    is_owner = (view_user == request.user)
    
    # Professional stats calculation
    stats = {}
    if view_user.role == 'teacher':
        teacher_courses = Course.objects.filter(teacher=view_user)
        stats['courses_count'] = teacher_courses.count()
        # Total unique students across all courses
        stats['students_count'] = Enrollment.objects.filter(course__in=teacher_courses).values('user').distinct().count()
        # Total reviews received across all courses
        stats['reviews_count'] = Review.objects.filter(course__in=teacher_courses).count()
    else:
        stats['courses_count'] = Enrollment.objects.filter(user=view_user).count()
        stats['achievements_count'] = Certificate.objects.filter(user=view_user).count()
        stats['reviews_count'] = Review.objects.filter(user=view_user).count()

    return render(request, 'eduverse_app/profile.html', {
        'view_user': view_user,
        'is_owner': is_owner,
        'stats': stats
    })

@login_required
def edit_profile_view(request):
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully!")
            return redirect('profile')
    else:
        form = UserProfileForm(instance=request.user)
    return render(request, 'eduverse_app/edit_profile.html', {'form': form})

# @login_required removed for public access
def course_list(request):
    query = request.GET.get('q')
    if query:
        courses = Course.objects.filter(
            Q(title__icontains=query) |
            Q(category__icontains=query)
        )
    else:
        courses = Course.objects.all()

    teachers = User.objects.filter(role='teacher')[:4]  # Get top 4 teachers

    return render(request, 'eduverse_app/course_list.html', {
        'courses': courses,
        'query': query,
        'teachers': teachers
    })

# @login_required removed for public access
def course_detail(request, pk):
    course = get_object_or_404(Course, pk=pk)
    is_enrolled = False
    if request.user.is_authenticated:
        is_enrolled = Enrollment.objects.filter(user=request.user, course=course).exists()
    
    # Handle Review Submission
    if request.method == 'POST' and 'submit_review' in request.POST:
        if not is_enrolled:
             messages.error(request, "You must be enrolled to leave a review.")
        else:
            review_form = ReviewForm(request.POST)
            if review_form.is_valid():
                review = review_form.save(commit=False)
                review.course = course
                review.user = request.user
                review.save()
                messages.success(request, "Review submitted successfully!")
                return redirect('course_detail', pk=pk)
    else:
        review_form = ReviewForm()

    reviews = course.reviews.all().order_by('-created_at')
    
    return render(request, 'eduverse_app/course_detail.html', {
        'course': course, 
        'is_enrolled': is_enrolled,
        'reviews': reviews,
        'review_form': review_form
    })

@login_required
def lesson_detail(request, course_id, lesson_id):
    course = get_object_or_404(Course, pk=course_id)
    lesson = get_object_or_404(Lesson, pk=lesson_id, course=course)
    
    # Check enrollment
    if not Enrollment.objects.filter(user=request.user, course=course).exists():
        messages.error(request, "You must be enrolled to view this lesson.")
        return redirect('course_detail', pk=course.id)
        
    # Mark as completed
    LessonProgress.objects.get_or_create(user=request.user, lesson=lesson, defaults={'completed': True, 'completed_at': timezone.now()})
    
    # Determine Next Lesson or Quiz
    next_lesson = Lesson.objects.filter(course=course, order__gt=lesson.order).order_by('order').first()
    quiz_available = False
    if not next_lesson:
        if hasattr(course, 'quiz'):
            quiz_available = True
    
    return render(request, 'eduverse_app/lesson_detail.html', {
        'course': course, 
        'lesson': lesson, 
        'next_lesson': next_lesson, 
        'quiz_available': quiz_available
    })

@login_required
def enroll_course(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == 'POST':
        # If the course is paid, redirect to stripe checkout
        if course.price > 0:
            return redirect('create_checkout_session', course_id=course.id)
            
        Enrollment.objects.get_or_create(user=request.user, course=course)
        messages.success(request, f"You have successfully enrolled in {course.title}!")
        return redirect('course_detail', pk=pk)
    return redirect('course_detail', pk=pk)

@login_required
def student_dashboard(request):
    enrollments = Enrollment.objects.filter(user=request.user).select_related('course')
    
    # Calculate progress for each enrollment
    dashboard_data = []
    for enrollment in enrollments:
        total_lessons = enrollment.course.lessons.count()
        completed_lessons = LessonProgress.objects.filter(user=request.user, lesson__course=enrollment.course, completed=True).count()
        progress = (completed_lessons / total_lessons * 100) if total_lessons > 0 else 0
        
        dashboard_data.append({
            'course': enrollment.course,
            'progress': round(progress),
            'completed_lessons': completed_lessons,
            'total_lessons': total_lessons
        })
        
    return render(request, 'eduverse_app/student_dashboard.html', {'dashboard_data': dashboard_data})

@login_required
def take_quiz(request, course_id):
    course = get_object_or_404(Course, pk=course_id)
    
    # Check enrollment
    if not Enrollment.objects.filter(user=request.user, course=course).exists():
        messages.error(request, "You must be enrolled to take the quiz.")
        return redirect('course_detail', pk=course.id)

    # Check if all lessons are completed
    total_lessons = course.lessons.count()
    completed_lessons = LessonProgress.objects.filter(user=request.user, lesson__course=course, completed=True).count()
    
    if completed_lessons < total_lessons:
        messages.warning(request, f"You have completed {completed_lessons} of {total_lessons} lessons. Please complete all lessons before taking the quiz.")
        return redirect('course_detail', pk=course.id)

    try:
        quiz = course.quiz
    except Quiz.DoesNotExist:
        messages.error(request, "No quiz available for this course.")
        return redirect('course_detail', pk=course.id)

    if request.method == 'POST':
        questions = quiz.questions.all()
        total_questions = questions.count()
        correct_count = 0
        
        if total_questions == 0:
            messages.error(request, "Quiz has no questions.")
            return redirect('course_detail', pk=course.id)

        answers = {}
        for question in questions:
            user_answer = request.POST.get(str(question.id))
            if user_answer:
                answers[str(question.id)] = user_answer
            
            if user_answer and user_answer == question.correct_answer:
                correct_count += 1
        
        score_percentage = (correct_count / total_questions) * 100
        passed = score_percentage >= quiz.passing_score
        
        # Save result
        result = ExamResult.objects.create(
            user=request.user,
            course=course,
            score=score_percentage,
            passed=passed,
            user_answers=answers
        )
        
        if passed:
            Certificate.objects.get_or_create(
                user=request.user,
                course=course,
                defaults={'issue_date': timezone.now()}
            )
            # Update enrollment
            enrollment = Enrollment.objects.get(user=request.user, course=course)
            if not enrollment.completed_at:
                enrollment.completed_at = timezone.now()
                enrollment.save()
            messages.success(request, f"Congratulations! You passed with {int(score_percentage)}%.")
        else:
             messages.warning(request, f"You scored {int(score_percentage)}%. You need {quiz.passing_score}% to pass. Try again!")

        return redirect('quiz_result', result_id=result.id)

    return render(request, 'eduverse_app/quiz.html', {'course': course, 'quiz': quiz})

@login_required
def quiz_result(request, result_id):
    # Ensure select_related includes 'course' and 'course__quiz' to avoid N+1 queries
    # Note: 'course__quiz' might strictly need double underscore if it was a forward relation,
    # but since it's OneToOne reverse, access is typically cached on the object or needs specific prefetch.
    # Simpler to just fetch result and access related objects.
    result = get_object_or_404(ExamResult, pk=result_id, user=request.user)
    certificate = None
    if result.passed:
        certificate = Certificate.objects.filter(user=request.user, course=result.course).first()
    
    incorrect_questions = []
    if hasattr(result.course, 'quiz'):
        questions = result.course.quiz.questions.all()
        user_answers = result.user_answers or {}
        
        for question in questions:
            # Check if answer is wrong
            user_ans = user_answers.get(str(question.id))
            if user_ans != question.correct_answer:
                incorrect_questions.append({
                    'question': question,
                    'user_answer': user_ans,
                    'correct_answer': question.correct_answer
                })
        
    return render(request, 'eduverse_app/quiz_result.html', {
        'result': result, 
        'certificate': certificate, 
        'incorrect_questions': incorrect_questions
    })

@login_required
def teacher_dashboard(request):
    if request.user.role != 'teacher':
        messages.error(request, "Access denied. Teachers only.")
        return redirect('student_dashboard')
    
    # Get courses and annotate with student count
    courses = Course.objects.filter(teacher=request.user).annotate(
        student_count=Count('enrollment')
    ).order_by('-created_at')
    
    # Simple stats for the teacher
    total_courses = courses.count()
    total_students = Enrollment.objects.filter(course__in=courses).values('user').distinct().count()
    
    context = {
        'courses': courses,
        'total_courses': total_courses,
        'total_students': total_students,
    }
    return render(request, 'eduverse_app/teacher_dashboard.html', context)

@login_required
def teacher_student_list(request):
    if request.user.role != 'teacher':
        messages.error(request, "Access denied.")
        return redirect('/')
    
    courses = Course.objects.filter(teacher=request.user)
    # Get distinct students enrolled in teacher's courses
    enrollments = Enrollment.objects.filter(course__in=courses).select_related('user', 'course').order_by('-enrolled_at')
    
    return render(request, 'eduverse_app/teacher_student_list.html', {
        'enrollments': enrollments,
    })

@login_required
def teacher_student_detail(request, user_id):
    if request.user.role != 'teacher':
        messages.error(request, "Access denied.")
        return redirect('/')
    
    student = get_object_or_404(User, id=user_id)
    teacher_courses = Course.objects.filter(teacher=request.user)
    
    # Check if student is actually enrolled in any of this teacher's courses
    if not Enrollment.objects.filter(user=student, course__in=teacher_courses).exists():
        messages.error(request, "This student is not enrolled in your courses.")
        return redirect('teacher_student_list')
    
    # Get enrollments for this student in teacher's courses
    enrollments = Enrollment.objects.filter(user=student, course__in=teacher_courses).select_related('course')
    
    # Activity tracking for teacher's courses ONLY
    lesson_progress = LessonProgress.objects.filter(
        user=student, 
        lesson__course__in=teacher_courses
    ).select_related('lesson', 'lesson__course').order_by('-completed_at')
    
    assignment_submissions = AssignmentSubmission.objects.filter(
        student=student, 
        assignment__course__in=teacher_courses
    ).select_related('assignment', 'assignment__course').order_by('-submitted_at')
    
    quiz_results = ExamResult.objects.filter(
        user=student, 
        course__in=teacher_courses
    ).select_related('course').order_by('-taken_at')
    
    return render(request, 'eduverse_app/teacher_student_detail.html', {
        'student': student,
        'enrollments': enrollments,
        'lesson_progress': lesson_progress,
        'assignment_submissions': assignment_submissions,
        'quiz_results': quiz_results,
    })

@login_required
def custom_admin_dashboard(request):
    if request.user.role != 'admin':
        messages.error(request, "Access denied. Admin only.")
        return redirect('student_dashboard')
        
    total_students = User.objects.filter(role='user').count()
    total_teachers = User.objects.filter(role='teacher').count()
    total_courses = Course.objects.count()
    total_enrollments = Enrollment.objects.count()
    recent_enrollments = Enrollment.objects.select_related('user', 'course').order_by('-enrolled_at')[:5]
    
    # Annotate courses with student count
    courses = Course.objects.annotate(student_count=Count('enrollment')).order_by('-created_at')
    
    context = {
        'total_students': total_students,
        'total_teachers': total_teachers,
        'total_courses': total_courses,
        'total_enrollments': total_enrollments,
        'recent_enrollments': recent_enrollments,
        'courses': courses
    }
    return render(request, 'eduverse_app/admin_dashboard.html', context)

@login_required
def admin_user_list(request):
    if request.user.role != 'admin':
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')
    
    users = User.objects.exclude(id=request.user.id)
    role_filter = request.GET.get('role')
    if role_filter:
        users = users.filter(role=role_filter)
    users = users.order_by('role', 'username')
    total_students = User.objects.filter(role='user').count()
    return render(request, 'eduverse_app/admin_user_list.html', {'users': users, 'total_students': total_students})

@login_required
def admin_course_list(request):
    if request.user.role != 'admin':
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')
    
    courses = Course.objects.annotate(student_count=Count('enrollment')).order_by('-created_at')
    total_courses = courses.count()
    return render(request, 'eduverse_app/admin_course_list.html', {'courses': courses, 'total_courses': total_courses})

@login_required
def admin_enrollment_list(request):
    if request.user.role != 'admin':
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')
    
    enrollments = Enrollment.objects.select_related('user', 'course').order_by('-enrolled_at')
    total_enrollments = enrollments.count()
    return render(request, 'eduverse_app/admin_enrollment_list.html', {'enrollments': enrollments, 'total_enrollments': total_enrollments})

@login_required
def admin_toggle_ban(request, pk):
    if request.user.role != 'admin':
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')
    
    user_to_ban = get_object_or_404(User, pk=pk)
    if user_to_ban.is_active:
        user_to_ban.is_active = False
        user_to_ban.save()
        messages.success(request, f"User {user_to_ban.username} has been banned.")
    else:
        user_to_ban.is_active = True
        user_to_ban.save()
        messages.success(request, f"User {user_to_ban.username} has been unbanned.")
        
    return redirect('admin_user_list')

@login_required
def admin_edit_user(request, pk):
    if request.user.role != 'admin':
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')
    
    user_to_edit = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=user_to_edit)
        # We also need to handle the role field which is NOT in UserProfileForm normally or let's check
        if form.is_valid():
            form.save()
            messages.success(request, f"User {user_to_edit.username} updated successfully.")
            return redirect('admin_user_list')
    else:
        form = UserProfileForm(instance=user_to_edit)
    
    return render(request, 'eduverse_app/admin_edit_user.html', {'form': form, 'user_to_edit': user_to_edit})

@login_required
def admin_delete_user(request, pk):
    if request.user.role != 'admin':
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')
    
    user_to_delete = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        username = user_to_delete.username
        user_to_delete.delete()
        messages.success(request, f"User {username} deleted successfully.")
        return redirect('admin_user_list')
    
    return render(request, 'eduverse_app/admin_delete_confirm.html', {'user_to_delete': user_to_delete})

# views.py
@login_required
def edit_course_view(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.user.role not in ['admin', 'teacher'] or (request.user.role == 'teacher' and course.teacher != request.user):
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES, instance=course)
        if form.is_valid():
            form.save()
            messages.success(request, f"Course '{course.title}' updated successfully!")
            return redirect('teacher_dashboard')
    else:
        form = CourseForm(instance=course)

    return render(request, 'eduverse_app/add_course.html', {'form': form, 'edit_mode': True, 'course': course})

@login_required
def add_course_view(request):
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES)
        if form.is_valid():
            course = form.save(commit=False)
            course.teacher = request.user
            course.save()
            return redirect('teacher_dashboard')
    else:
        form = CourseForm()

    return render(request, 'eduverse_app/add_course.html', {'form': form})

@login_required
def delete_course_view(request, pk):
    if request.user.role not in ['admin', 'teacher']:
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')
        
    course = get_object_or_404(Course, pk=pk)
    
    # Check ownership for teachers
    if request.user.role == 'teacher' and course.teacher != request.user:
        messages.error(request, "You can only delete your own courses.")
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        course.delete()
        messages.success(request, f"Course '{course.title}' deleted successfully.")
    
    if request.user.role == 'teacher':
        return redirect('teacher_dashboard')
    return redirect('custom_admin_dashboard')

@login_required
def manage_quiz_view(request, course_id):
    if request.user.role not in ['admin', 'teacher']:
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')
        
    course = get_object_or_404(Course, pk=course_id)
    
    # Check ownership for teachers
    if request.user.role == 'teacher' and course.teacher != request.user:
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    quiz = getattr(course, 'quiz', None)

    if request.method == 'POST':
        if 'delete_quiz' in request.POST:
            if quiz:
                messages.success(request, "Quiz deleted successfully.")
                if request.user.role == 'teacher':
                    return redirect('teacher_dashboard')
                return redirect('custom_admin_dashboard')
        else:
            form = QuizForm(request.POST, instance=quiz)
            if form.is_valid():
                quiz = form.save(commit=False)
                quiz.course = course
                quiz.save()
                messages.success(request, "Quiz saved successfully!")
                if request.user.role == 'teacher':
                    return redirect('teacher_dashboard')
                return redirect('custom_admin_dashboard')
    else:
        form = QuizForm(instance=quiz)

    return render(request, 'eduverse_app/quiz_form.html', {'form': form, 'course': course, 'quiz': quiz})

@login_required
def edit_lesson_view(request, lesson_id):
    lesson = get_object_or_404(Lesson, pk=lesson_id)
    course = lesson.course
    if request.user.role not in ['admin', 'teacher'] or (request.user.role == 'teacher' and course.teacher != request.user):
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        form = LessonForm(request.POST, request.FILES, instance=lesson)
        if form.is_valid():
            form.save()
            messages.success(request, f"Lesson '{lesson.title}' updated successfully!")
            return redirect('course_detail', pk=course.id)
    else:
        form = LessonForm(instance=lesson)

    return render(request, 'eduverse_app/lesson_form.html', {'form': form, 'course': course, 'edit_mode': True, 'lesson': lesson})

@login_required
def delete_lesson_view(request, lesson_id):
    lesson = get_object_or_404(Lesson, pk=lesson_id)
    course = lesson.course
    if request.user.role not in ['admin', 'teacher'] or (request.user.role == 'teacher' and course.teacher != request.user):
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        lesson.delete()
        messages.success(request, "Lesson deleted successfully.")
    
    return redirect('course_detail', pk=course.id)

@login_required
def add_lesson_view(request, course_id):
    if request.user.role not in ['admin', 'teacher']:
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')

        return redirect('student_dashboard')

    course = get_object_or_404(Course, pk=course_id)
    
    # Check ownership for teachers
    if request.user.role == 'teacher' and course.teacher != request.user:
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')
    
    if request.method == 'POST':
        form = LessonForm(request.POST, request.FILES)
        if form.is_valid():
            lesson = form.save(commit=False)
            lesson.course = course
            lesson.save()
            messages.success(request, f"Lesson '{lesson.title}' added successfully!")
            if request.user.role == 'teacher':
                return redirect('teacher_dashboard')
            return redirect('custom_admin_dashboard') # Or redirect to course edit page if we had one
    else:
        form = LessonForm()

    return render(request, 'eduverse_app/lesson_form.html', {'form': form, 'course': course})

@login_required
def add_question_view(request, quiz_id):
    if request.user.role not in ['admin', 'teacher']:
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')

        return redirect('student_dashboard')

    quiz = get_object_or_404(Quiz, pk=quiz_id)
    
    # Check ownership
    if request.user.role == 'teacher' and quiz.course.teacher != request.user:
         messages.error(request, "Access denied.")
         return redirect('teacher_dashboard')
    
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.quiz = quiz
            question.save()
            messages.success(request, "Question added successfully!")
            return redirect('manage_quiz', course_id=quiz.course.id)
    else:
        form = QuestionForm()

    return render(request, 'eduverse_app/question_form.html', {'form': form, 'quiz': quiz})

@login_required
def delete_question_view(request, question_id):
    if request.user.role not in ['admin', 'teacher']:
        messages.error(request, "Access denied.")
        return redirect('student_dashboard')

    question = get_object_or_404(Question, pk=question_id)
    quiz_id = question.quiz.id
    course_id = question.quiz.course.id

    # Check ownership
    if request.user.role == 'teacher' and question.quiz.course.teacher != request.user:
         messages.error(request, "Access denied.")
         return redirect('teacher_dashboard')
    
    if request.method == 'POST':
        question.delete()
        messages.success(request, "Question deleted successfully.")
    
    return redirect('manage_quiz', course_id=course_id)

# Live Class Views
@login_required
def edit_live_class_view(request, pk):
    live_class = get_object_or_404(LiveClass, pk=pk)
    course = live_class.course
    if request.user.role not in ['admin', 'teacher'] or (request.user.role == 'teacher' and live_class.teacher != request.user):
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        form = LiveClassForm(request.POST, instance=live_class)
        if form.is_valid():
            form.save()
            messages.success(request, f"Live class '{live_class.title}' updated successfully!")
            return redirect('course_detail', pk=course.id)
    else:
        form = LiveClassForm(instance=live_class)

    return render(request, 'eduverse_app/live_class_form.html', {'form': form, 'course': course, 'edit_mode': True, 'live_class': live_class})

@login_required
def add_live_class(request, course_id):
    course = get_object_or_404(Course, pk=course_id)
    if request.user.role not in ['admin', 'teacher'] or (request.user.role == 'teacher' and course.teacher != request.user):
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        form = LiveClassForm(request.POST)
        if form.is_valid():
            live_class = form.save(commit=False)
            live_class.course = course
            live_class.teacher = request.user
            live_class.save()
            messages.success(request, f"Live class '{live_class.title}' scheduled successfully!")
            return redirect('course_detail', pk=course.id)
    else:
        form = LiveClassForm()

    return render(request, 'eduverse_app/live_class_form.html', {'form': form, 'course': course})

@login_required
def live_class_detail(request, pk):
    live_class = get_object_or_404(LiveClass, pk=pk)
    course = live_class.course
    is_enrolled = Enrollment.objects.filter(user=request.user, course=course).exists()
    is_teacher = (request.user == live_class.teacher or request.user.role == 'admin')

    if not is_enrolled and not is_teacher:
        messages.error(request, "You must be enrolled to join this live class.")
        return redirect('course_detail', pk=course.id)

    questions = live_class.questions.all().order_by('-created_at')
    
    # Forms for interaction
    question_form = LiveClassQuestionForm()
    answer_form = LiveClassAnswerForm()

    if request.method == 'POST':
        if 'submit_question' in request.POST and is_teacher:
            q_form = LiveClassQuestionForm(request.POST)
            if q_form.is_valid():
                question = q_form.save(commit=False)
                question.live_class = live_class
                question.teacher = request.user
                question.save()
                messages.success(request, "Question posted for students!")
                return redirect('live_class_detail', pk=pk)
        
        elif 'submit_answer' in request.POST:
            question_id = request.POST.get('question_id')
            question = get_object_or_404(LiveClassQuestion, pk=question_id, live_class=live_class)
            a_form = LiveClassAnswerForm(request.POST)
            if a_form.is_valid():
                answer = a_form.save(commit=False)
                answer.question = question
                answer.student = request.user
                answer.save()
                messages.success(request, "Answer submitted!")
                return redirect('live_class_detail', pk=pk)

    return render(request, 'eduverse_app/live_class_detail.html', {
        'live_class': live_class,
        'questions': questions,
        'question_form': question_form,
        'answer_form': answer_form,
        'is_teacher': is_teacher
    })

@login_required
def delete_live_class(request, pk):
    live_class = get_object_or_404(LiveClass, pk=pk)
    course_id = live_class.course.id
    if request.user.role == 'admin' or (request.user.role == 'teacher' and live_class.teacher == request.user):
        live_class.delete()
        messages.success(request, "Live class deleted.")
    else:
        messages.error(request, "Access denied.")
    return redirect('course_detail', pk=course_id)

@login_required
def add_assignment_view(request, course_id):
    course = get_object_or_404(Course, pk=course_id)
    if request.user.role not in ['admin', 'teacher'] or (request.user.role == 'teacher' and course.teacher != request.user):
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        form = AssignmentForm(request.POST, request.FILES)
        if form.is_valid():
            assignment = form.save(commit=False)
            assignment.course = course
            assignment.save()
            messages.success(request, f"Assignment '{assignment.title}' created successfully!")
            return redirect('course_detail', pk=course.id)
    else:
        form = AssignmentForm()

    return render(request, 'eduverse_app/assignment_form.html', {'form': form, 'course': course})

@login_required
def edit_assignment_view(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk)
    course = assignment.course
    if request.user.role not in ['admin', 'teacher'] or (request.user.role == 'teacher' and course.teacher != request.user):
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        form = AssignmentForm(request.POST, request.FILES, instance=assignment)
        if form.is_valid():
            form.save()
            messages.success(request, f"Assignment '{assignment.title}' updated successfully!")
            return redirect('course_detail', pk=course.id)
    else:
        form = AssignmentForm(instance=assignment)

    return render(request, 'eduverse_app/assignment_form.html', {'form': form, 'course': course, 'edit_mode': True})

@login_required
def delete_assignment_view(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk)
    course_id = assignment.course.id
    if request.user.role == 'admin' or (request.user.role == 'teacher' and assignment.course.teacher == request.user):
        assignment.delete()
        messages.success(request, "Assignment deleted successfully.")
    else:
        messages.error(request, "Access denied.")
    return redirect('course_detail', pk=course_id)

@login_required
def submit_assignment_view(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk)
    course = assignment.course
    is_enrolled = Enrollment.objects.filter(user=request.user, course=course).exists()
    
    if not is_enrolled:
        messages.error(request, "You must be enrolled to submit assignments.")
        return redirect('course_detail', pk=course.id)

    submission = AssignmentSubmission.objects.filter(assignment=assignment, student=request.user).first()

    if request.method == 'POST':
        form = AssignmentSubmissionForm(request.POST, request.FILES, instance=submission)
        if form.is_valid():
            new_submission = form.save(commit=False)
            new_submission.assignment = assignment
            new_submission.student = request.user
            new_submission.save()
            messages.success(request, "Assignment submitted successfully!")
            return redirect('course_detail', pk=course.id)
    else:
        form = AssignmentSubmissionForm(instance=submission)

    return render(request, 'eduverse_app/submit_assignment.html', {
        'form': form, 
        'assignment': assignment,
        'submission': submission
    })

@login_required
def view_submissions_view(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk)
    if request.user.role not in ['admin', 'teacher'] or (request.user.role == 'teacher' and assignment.course.teacher != request.user):
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    submissions = assignment.submissions.all().select_related('student')
    return render(request, 'eduverse_app/submission_list.html', {
        'assignment': assignment,
        'submissions': submissions
    })

@login_required
def grade_submission_view(request, pk):
    submission = get_object_or_404(AssignmentSubmission, pk=pk)
    if request.user.role not in ['admin', 'teacher'] or (request.user.role == 'teacher' and submission.assignment.course.teacher != request.user):
        messages.error(request, "Access denied.")
        return redirect('teacher_dashboard')

    if request.method == 'POST':
        grade = request.POST.get('grade')
        feedback = request.POST.get('feedback')
        submission.grade = grade
        submission.feedback = feedback
        submission.save()
        messages.success(request, f"Submission by {submission.student.username} graded successfully!")
        return redirect('view_submissions', pk=submission.assignment.id)

    return render(request, 'eduverse_app/grade_submission.html', {'submission': submission})

# --- Stripe Payment Gateway ---

stripe.api_key = settings.STRIPE_SECRET_KEY

@login_required
def create_checkout_session(request, course_id):
    course = get_object_or_404(Course, pk=course_id)
    
    # Check if already enrolled
    if Enrollment.objects.filter(user=request.user, course=course).exists():
        messages.info(request, "You are already enrolled in this course.")
        return redirect('course_detail', pk=course.id)

    # Free course logic
    if course.price == 0:
        Enrollment.objects.create(user=request.user, course=course)
        messages.success(request, f"Successfully enrolled in {course.title}!")
        return redirect('course_detail', pk=course.id)

    # Stripe session creation
    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[
                {
                    'price_data': {
                        'currency': settings.STRIPE_CURRENCY,
                        'unit_amount': int(course.price * 100), # Amout in cents
                        'product_data': {
                            'name': course.title,
                        },
                    },
                    'quantity': 1,
                },
            ],
            mode='payment',
            success_url=request.build_absolute_uri(reverse('payment_success')) + f"?session_id={{CHECKOUT_SESSION_ID}}&course_id={course.id}",
            cancel_url=request.build_absolute_uri(reverse('payment_cancel')),
        )
        
        # Create a pending payment record
        Payment.objects.create(
            user=request.user,
            course=course,
            stripe_session_id=checkout_session.id,
            amount=course.price,
            status='pending'
        )
        
        return redirect(checkout_session.url, code=303)
    except Exception as e:
        messages.error(request, f"Payment error: {str(e)}")
        return redirect('course_detail', pk=course.id)

@login_required
def payment_success(request):
    session_id = request.GET.get('session_id')
    course_id = request.GET.get('course_id')
    
    if session_id and course_id:
        try:
            # Verify with Stripe
            session = stripe.checkout.Session.retrieve(session_id)
            if session.payment_status == 'paid':
                payment = get_object_or_404(Payment, stripe_session_id=session_id)
                payment.status = 'completed'
                payment.save()
                
                # Enroll the user
                course = get_object_or_404(Course, pk=course_id)
                Enrollment.objects.get_or_create(user=request.user, course=course)
                
                messages.success(request, f"Payment successful! You are now enrolled in {course.title}.")
                return redirect('course_detail', pk=course.id)
        except Exception as e:
            messages.error(request, f"Verification error: {str(e)}")
            
    messages.error(request, "Payment verification failed.")
    return redirect('course_list')

@login_required
def payment_cancel(request):
    messages.warning(request, "Payment was cancelled.")
    return redirect('course_list')

