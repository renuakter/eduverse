from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.units import inch
from reportlab.lib.colors import blue, black
from io import BytesIO
from django.conf import settings
import os

def generate_certificate_pdf(certificate):
    """
    Generate a PDF certificate for the given certificate instance
    """
    buffer = BytesIO()

    # Create the PDF document
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle(
        'Title',
        parent=styles['Title'],
        fontSize=24,
        spaceAfter=30,
        alignment=1,  # Center alignment
        textColor=blue
    )

    normal_style = ParagraphStyle(
        'Normal',
        parent=styles['Normal'],
        fontSize=12,
        spaceAfter=20,
        alignment=1
    )

    certificate_style = ParagraphStyle(
        'Certificate',
        parent=styles['Normal'],
        fontSize=16,
        spaceAfter=20,
        alignment=1,
        textColor=blue
    )

    # Build the content
    content = []

    # Title
    content.append(Paragraph("Certificate of Completion", title_style))
    content.append(Spacer(1, 0.5*inch))

    # Certificate text
    content.append(Paragraph("This is to certify that", normal_style))
    content.append(Spacer(1, 0.2*inch))

    # Student name
    full_name = f"{certificate.user.first_name} {certificate.user.last_name}".strip()
    if not full_name:
        full_name = certificate.user.username
    content.append(Paragraph(f"<b>{full_name}</b>", certificate_style))
    content.append(Spacer(1, 0.2*inch))

    # Course completion text
    content.append(Paragraph("has successfully completed the course", normal_style))
    content.append(Spacer(1, 0.2*inch))

    # Course name
    content.append(Paragraph(f"<b>{certificate.course.title}</b>", certificate_style))
    content.append(Spacer(1, 0.2*inch))

    # Issue details
    content.append(Paragraph(f"Certificate ID: {certificate.certificate_id}", normal_style))
    content.append(Paragraph(f"Issued on: {certificate.issue_date.strftime('%B %d, %Y')}", normal_style))
    content.append(Spacer(1, 0.5*inch))

    # Platform name
    content.append(Paragraph("EduVerse - Online Learning Platform", normal_style))

    # Build the PDF
    doc.build(content)

    buffer.seek(0)
    return buffer

def save_certificate_pdf(certificate):
    """
    Generate and save the PDF certificate to the certificate instance
    """
    pdf_buffer = generate_certificate_pdf(certificate)

    # Create certificates directory if it doesn't exist
    cert_dir = os.path.join(settings.MEDIA_ROOT, 'certificates')
    os.makedirs(cert_dir, exist_ok=True)

    # Save the PDF file
    filename = f"certificate_{certificate.certificate_id}.pdf"
    filepath = os.path.join(cert_dir, filename)

    with open(filepath, 'wb') as f:
        f.write(pdf_buffer.getvalue())

    # Update the certificate instance
    certificate.pdf_file.name = f"certificates/{filename}"
    certificate.save()

    return filepath
