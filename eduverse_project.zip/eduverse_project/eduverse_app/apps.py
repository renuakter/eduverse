from django.apps import AppConfig


class EduverseAppConfig(AppConfig):
    name = 'eduverse_app'
