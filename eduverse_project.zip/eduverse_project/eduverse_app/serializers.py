from rest_framework import serializers
from django.contrib.auth import authenticate
from .models import User, Course, Lesson, Quiz, Question, ExamResult, Certificate, Enrollment, LessonProgress

class UserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    password2 = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'first_name', 'last_name', 'role', 'password', 'password2')

    def validate(self, attrs):
        if attrs.get('password') != attrs.get('password2'):
            raise serializers.ValidationError("Passwords don't match")
        return attrs

    def create(self, validated_data):
        validated_data.pop('password2')
        user = User.objects.create_user(**validated_data)
        return user

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

    def validate(self, attrs):
        username = attrs.get('username')
        password = attrs.get('password')

        if username and password:
            user = authenticate(username=username, password=password)
            if not user:
                raise serializers.ValidationError('Invalid credentials')
            if not user.is_active:
                raise serializers.ValidationError('User account is disabled')
            attrs['user'] = user
            return attrs
        else:
            raise serializers.ValidationError('Must include username and password')

class CourseSerializer(serializers.ModelSerializer):
    lessons_count = serializers.SerializerMethodField()
    quiz = serializers.SerializerMethodField()

    class Meta:
        model = Course
        fields = ('id', 'title', 'description', 'category', 'teacher', 'created_at', 'lessons_count', 'quiz')

    def get_lessons_count(self, obj):
        return obj.lessons.count()

    def get_quiz(self, obj):
        try:
            quiz = obj.quiz
            return QuizSerializer(quiz).data
        except:
            return None

class LessonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lesson
        fields = ('id', 'title', 'video_url', 'order')

class QuizSerializer(serializers.ModelSerializer):
    questions = serializers.SerializerMethodField()

    class Meta:
        model = Quiz
        fields = ('id', 'title', 'passing_score', 'questions')

    def get_questions(self, obj):
        if hasattr(self.context.get('request'), 'method') and self.context['request'].method == 'GET':
            include_questions = self.context.get('include_questions', False)
            if include_questions:
                return QuestionSerializer(obj.questions.all(), many=True).data
        return []

class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ('id', 'question_text', 'options', 'correct_answer')

class ExamResultSerializer(serializers.ModelSerializer):
    user = serializers.StringRelatedField()
    course = serializers.StringRelatedField()

    class Meta:
        model = ExamResult
        fields = ('id', 'user', 'course', 'score', 'passed', 'taken_at')

class CertificateSerializer(serializers.ModelSerializer):
    user = serializers.StringRelatedField()
    course = serializers.StringRelatedField()

    class Meta:
        model = Certificate
        fields = ('id', 'user', 'course', 'certificate_id', 'issue_date', 'pdf_file')

class EnrollmentSerializer(serializers.ModelSerializer):
    course = CourseSerializer(read_only=True)
    user = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Enrollment
        fields = ('id', 'user', 'course', 'enrolled_at', 'completed_at')
        read_only_fields = ('enrolled_at', 'completed_at')

class LessonProgressSerializer(serializers.ModelSerializer):
    lesson = LessonSerializer(read_only=True)
    user = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = LessonProgress
        fields = ('id', 'user', 'lesson', 'course', 'completed', 'completed_at')
        read_only_fields = ('completed_at',)
