from django import template
import re
import os

register = template.Library()

@register.filter
def get_video_url(lesson):
    """
    Returns the appropriate video URL based on available sources.
    Priority: 1. YouTube URL, 2. Uploaded video file
    """
    # Check if YouTube URL exists
    if lesson.video_url:
        return youtube_embed(lesson.video_url)
    
    # Check if video file exists
    elif lesson.video_file:
        return lesson.video_file.url
    
    return ""

@register.filter
def youtube_embed(url):
    """
    Converts YouTube URL to embed URL with NO suggestions
    """
    if not url:
        return ""
    
    # Regex for YouTube ID
    regex = r'(?:https?:\/\/)?(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|v\/|shorts\/)|youtu\.be\/)([\w\-]{11})'
    match = re.search(regex, url)
    
    if match:
        video_id = match.group(1)
        
        # Use youtube-nocookie.com for privacy
        embed_url = f"https://www.youtube-nocookie.com/embed/{video_id}"
        
        # Parameters to disable suggestions
        params = [
            "rel=0",  # No related videos
            "modestbranding=1",
            "controls=1",
            "showinfo=0",
            "iv_load_policy=3",
            "fs=1",
            "playsinline=1",
            "disablekb=1",
            "autoplay=0",
            "cc_load_policy=1",
            "color=white",
            "theme=light",
        ]
        
        return f"{embed_url}?{'&'.join(params)}"
    
    return url

@register.filter
def is_youtube_url(url):
    """
    Check if the URL is a YouTube URL
    """
    if not url:
        return False
    
    youtube_patterns = [
        r'youtube\.com',
        r'youtu\.be',
        r'youtube-nocookie\.com'
    ]
    
    for pattern in youtube_patterns:
        if re.search(pattern, url):
            return True
    
    return False

@register.filter
def get_video_type(lesson):
    """
    Returns the type of video: 'youtube', 'uploaded', or 'none'
    """
    if lesson.video_url and is_youtube_url(lesson.video_url):
        return 'youtube'
    elif lesson.video_file:
        return 'uploaded'
    return 'none'