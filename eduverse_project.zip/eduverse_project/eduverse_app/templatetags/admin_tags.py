from django import template
from eduverse_app.models import User, Course, Enrollment

register = template.Library()

@register.simple_tag
def get_admin_stats():
    return {
        'total_students': User.objects.filter(role='user').count(),
        'total_courses': Course.objects.count(),
        'total_enrollments': Enrollment.objects.count(),
    }
