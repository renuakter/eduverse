from django.db import models

class SiteSetting(models.Model):
    site_name = models.CharField(max_length=200, default='EduVerse')
    logo_text_part1 = models.CharField(max_length=100, default='Edu')
    logo_text_part2 = models.CharField(max_length=100, default='Verse')
    
    # Address
    address = models.TextField(default="Level-4, 34, Awal Centre,\nBanani, Dhaka")
    
    # Contact
    contact_email = models.EmailField(default='support@phitron.io')
    helpline_text = models.TextField(default="01322-810881\n01335-106732\n01322-810871")
    helpline_availability = models.CharField(max_length=100, default='(Available : 10AM - 5PM)')
    
    # Footer Bottom
    copyright_text = models.CharField(max_length=255, default='Copyright © 2026 Phitron.io')
    trade_license = models.CharField(max_length=100, default='177159')
    version = models.CharField(max_length=50, default='v 1.0.0')

    # Social Media
    facebook_url = models.URLField(blank=True, null=True, default='https://facebook.com')
    twitter_url = models.URLField(blank=True, null=True, default='https://twitter.com')
    linkedin_url = models.URLField(blank=True, null=True, default='https://linkedin.com')
    
    # App
    app_download_link = models.URLField(blank=True, null=True, default='#')

    def save(self, *args, **kwargs):
        # Ensure only one instance exists
        if not self.pk and SiteSetting.objects.exists():
            return
        return super(SiteSetting, self).save(*args, **kwargs)

    def __str__(self):
        return "Site Configuration"

class FooterLink(models.Model):
    title = models.CharField(max_length=100)
    url = models.CharField(max_length=200, default='#')
    order = models.PositiveIntegerField(default=0)
    
    class Meta:
        ordering = ['order']
        
    def __str__(self):
        return self.title
