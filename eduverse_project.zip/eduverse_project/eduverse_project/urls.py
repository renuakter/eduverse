"""
URL configuration for eduverse_project project.

It exposes the URL patterns for the entire project. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework_simplejwt.views import TokenRefreshView
from eduverse_app.views import (
    RegisterView, LoginView, CourseListView, CourseDetailView, LessonListView,
    QuizDetailView, TakeExamView, UserCertificatesView, EnrollmentListView,
    EnrollmentDetailView, LessonProgressListView, LessonProgressDetailView,
    AdminDashboardView, AdminUserManagementView, AdminExamResultsView, AdminCertificatesView,
    register_view, login_view, logout_view,
    course_list, course_detail, lesson_detail,
    enroll_course, student_dashboard,
    take_quiz, quiz_result, custom_admin_dashboard,
    add_course_view, delete_course_view, manage_quiz_view,
    add_lesson_view, add_question_view, delete_question_view,
    profile_view, edit_profile_view, teacher_dashboard,
    admin_user_list, admin_edit_user, admin_delete_user, admin_toggle_ban,
    admin_course_list, admin_enrollment_list
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/admin/certificates/', AdminCertificatesView.as_view(), name='admin-certificates'),

    # Template Views
    path('', course_list, name='course_list'),
    path('courses/<int:pk>/', course_detail, name='course_detail'),
    path('courses/<int:pk>/enroll/', enroll_course, name='enroll_course'),
    path('courses/<int:course_id>/lessons/<int:lesson_id>/', lesson_detail, name='lesson_detail'),
    path('courses/<int:course_id>/quiz/', take_quiz, name='take_quiz'),
    path('quiz/result/<int:result_id>/', quiz_result, name='quiz_result'),
    path('dashboard/', student_dashboard, name='student_dashboard'),
    path('teacher-dashboard/', teacher_dashboard, name='teacher_dashboard'),
    path('admin-dashboard/', custom_admin_dashboard, name='custom_admin_dashboard'),
    path('register/', register_view, name='register'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('profile/', profile_view, name='profile'),
    path('profile/edit/', edit_profile_view, name='edit_profile'),
    
    # Management Views
    path('add-course/', add_course_view, name='add_course'),
    path('courses/<int:pk>/delete/', delete_course_view, name='delete_course'),
    path('courses/<int:course_id>/quiz/manage/', manage_quiz_view, name='manage_quiz'),
    path('courses/<int:course_id>/lessons/add/', add_lesson_view, name='add_lesson'),
    path('quiz/<int:quiz_id>/questions/add/', add_question_view, name='add_question'),
    path('questions/<int:question_id>/delete/', delete_question_view, name='delete_question'),

    # Admin User Management
    path('admin-dashboard/users/', admin_user_list, name='admin_user_list'),
    path('admin-dashboard/users/<int:pk>/edit/', admin_edit_user, name='admin_edit_user'),
    path('admin-dashboard/users/<int:pk>/delete/', admin_delete_user, name='admin_delete_user'),
    path('admin-dashboard/users/<int:pk>/ban/', admin_toggle_ban, name='admin_toggle_ban'),
    path('admin-dashboard/courses/', admin_course_list, name='admin_course_list'),
    path('admin-dashboard/enrollments/', admin_enrollment_list, name='admin_enrollment_list'),
]

# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

